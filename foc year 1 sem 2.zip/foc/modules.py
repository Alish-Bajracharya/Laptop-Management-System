import datetime

#welcome page-----------------------------------------------
def welcome():
    print("\t\t\t\tAlish Electronics\t\t\t\t")
    print("\t\t\tDamak-06, Jhapa Contact=9824071911\t")
    print("--------------------------------------------------------------------------")
    print("|\t\t\t\t\t\t\t\t\t |")
    print("|\t\t\tWelcome to Laptop Management System\t\t|")
    print("|\t\t\t\t\t\t\t\t\t |")
    print("--------------------------------------------------------------------------\n\n")
#----------------------------------------------------------------------------------------------------------

def getTime():
    current_time = str(datetime.datetime.now())
    return current_time

#getting data from laptop.txt file
def laptoplist():
    with open('laptop.txt', 'r') as f3:
        results = []
        for line in f3:
            words = line.split(',')
            results.append((words[0:]))
    return results
#----------------------------------------------------------------------------------------------------------


#option section--------------------------------------------------------------------------------------------------------
def options():
    print("Press any of following number to select an option")
    print("1. Display Laptop")
    print("2. Sell Laptop")
    print("3. Purchase Laptop")
    print("4. Exit the program\n")

    option = 0
    while not option in range(1,5):
        try:
            option = int(input("Enter your choice(1-4): "))
        except:
            print("\n\nPlease enter a valid number between 1-5:\n")

    if option > 4 or option < 1:
        print("\nInvalid Option! Select only number listed below")
        options()
    elif(option == 1):
        displaylaptop()
    elif(option == 2):
        sellLaptop()
    elif(option == 3):
        purchaselaptop()
    elif(option == 4):
        print("Thank You for visiting")
        quit()
#----------------------------------------------------------------------------------------------------------


# displaying list of laptops with their details
def printLaptop():
    results = laptoplist()
    print("\n")
    print("-----------------------------------------------------------------------------------------------------------------------------------")
    print("ID \t Laptop-Name   \t  Brand Name  \t Price  \t Quantity  \t Processor  \t Graphic")
    print("-----------------------------------------------------------------------------------------------------------------------------------")

    for v in results:
        id,name, brand, price, quantity, processor, graphic = v
        print("{:<8} {:<17} {:<12} {:<18} {:<11} {:<15} {}".format(id,name, brand, price, quantity, processor, graphic.replace('\n','')))



def displaylaptop():
    print("\n\n------------------")
    print("|   Display Laptop   |")
    print("------------------\n")
    printLaptop()
    print('\n')
    options()
#----------------------------------------------------------------------------------------------------------


# purchase section--------------------------------------------------------------------------------------
def purchaselaptop():
    print("\n\n----------------------")
    print("|   Purchase Laptop   |")
    print("----------------------\n")
    name = input("\nEnter the name of the buyer: ")
    address = input("\nEnter the address of the buyer: ")
    contact = input("\nEnter the contact of the buyer: ")
    date = getTime()

    buyMore = True
    allLaptop = []
    while buyMore:
        printLaptop()
        Laptop = -1
        laptopQ = -1
        results = laptoplist()
        while Laptop < 0:
            try:
                Laptop = int(input("\nEnter the id of laptop you want to purchase: "))
                if Laptop < 0:
                    print("Error message! Please enter positive value ")
                if Laptop > len(results):
                    print("Laptop id isn't available")
                    Laptop = -1
            except:
                print("Error message! Please enter integer value")
        while laptopQ < 0:        
            try:
                laptopQ = int(input("\nEnter the total quantity you want to purchase: "))
                if laptopQ < 0:
                    print("Error message! Please enter positive value ")
                if laptopQ > int(laptoplist()[Laptop][4]):
                    print("\nSorry, We do not have enough quantity in our stock. Please try with fewer laptops.\n\n")
                    laptopQ = -1
            except:
                print("Error message! Please enter integer value")

            
        results[Laptop][4] = str(int(results[Laptop][4]) - laptopQ)


        timestamp = datetime.datetime.timestamp(datetime.datetime.now())

        fileName = "PURCHASE_BILL_"+ name + "_" + str(timestamp) + ".txt"

        with open('laptop.txt', 'w') as f2:
            data = ""
            for i in results:
                for j in i:
                    data += str(j)+","
                data = data[:-1]
            f2.write(data)

        allLaptop.append({"id": Laptop, "quantity": laptopQ})
        print("\nLaptop added for purchase.")
        buyMore = False

        with open(fileName, 'w') as f:
            f.write('Buyer Name: ' + name + '\nBuyer Address: ' + address + '\nBuyer Contact: ' + contact + '\nPurchase Date: ' + date + '\n\n\nLaptops Purchased:\n---------------------------------------------------------\n')


        grandTotal = 0
        for i in allLaptop:
            with open(fileName, 'a') as f:
                id = i.get("id")
                quantity = i.get("quantity")
                f.write('Laptop Name: ' + results[id][1] + '\nLaptop Brand: ' + results[id][2] + '\nUnit Price: ' + results[id][3] + '\nQuantity: ' + str(quantity) + '\nProcessor: ' + results[id][5] + '\nGraphic: ' + results[id][6] + '\nTotal Amount (without shipping cost): $' + str(int(results[id][3].replace('$','')) * quantity) + '\nShipping Company: ' + results[id][1] + '\nShipping Cost: $100'  + '\n' '\n\n---------------------------------------------------------\n\n')
            grandTotal = grandTotal + int(results[id][3].replace('$',''))*quantity + 100

        with open(fileName, 'a') as f:
            f.write('\nGrand Total (with shipping cost): $' + str(grandTotal))

        print('\n\n Your selected laptop were purchased successfully. \n')
      
    options()

#----------------------------------------------------------------------------------------------------------


# adding stock section--------------------------------------------------------------------------------------------
def sellLaptop():
    print("\n\n------------------")
    print("|   Sell Laptop   |")
    print("------------------\n")
 
    name = input("\nEnter the name of the Distributor: ")
    address = input("\nEnter the address of the Distributor: ")
    contact = input("\nEnter the contact number of the Distributor: ")
    date = getTime()

    #stockName = name + getTime() + '.txt'
    addMore = True
    allLaptop = {}
    while addMore:
        printLaptop()
        laptopDetails = []
        laptop = -1
        laptopQ = -1
        results = laptoplist()
        while laptop < 0:
            try:
                laptop = int(input("\nEnter the id of laptop you want to sell: "))
                if laptop < 0:
                    print("Error message! Please enter positive value ")
                if laptop > len(results):
                    print("Laptop id isn't available")
                    laptop = -1
            except:
                print("Error message! Please enter integer value")
        while laptopQ < 0:        
            try:
                laptopQ = int(input("\nEnter the total quantity you want to sell: "))
                if laptopQ < 0:
                    print("Error message! Please enter positive value ")
                
            except:
                print("Error message! Please enter integer value")
        
        ship = input("\nEnter the name of the Shipping Company: ")
        shipCost = input("\nEnter the shipping Cost: ")
        laptopDetails = [laptopQ,ship,shipCost.replace('$','')]
        
            
        results = laptoplist()
        
        timestamp = datetime.datetime.timestamp(datetime.datetime.now())

        fileName = "ADD_STOCK_BILL_"+ name + "_" + str(timestamp) + ".txt"

        results[laptop][4] = str(int(results[laptop][4]) + laptopQ)
        with open('laptop.txt', 'w') as f2:
            data = ""
            for i in results:
                for j in i:
                    data += str(j)+","
                data = data[:-1]
            f2.write(data)

        allLaptop.update({laptop:laptopDetails})
        print("\nLaptop added to the stock.")
        addMore = False

        with open(fileName, 'w') as f:
            f.write('Distributor Name: ' + name + '\nDistributor Address: ' + address + '\nDistributor Contact: ' + contact + '\nTransation Date: ' + date + '\n\n\nLaptop Added:\n---------------------------------------------------------\n')

        grandTotal = 0
        for i in allLaptop:
            with open(fileName, 'a') as f:
                f.write('Laptop Name: ' + results[i][1] + '\nLaptop Brand: ' + results[i][2] + '\nUnit Price: ' + results[i][3] + '\nQuantity: ' + str(allLaptop[i][0]) + '\nProcessor: ' + results[i][5] + '\nGraphic: ' + results[i][6] + '\nTotal Amount (without VAT): $' + str(int(results[i][3].replace('$',''))*allLaptop[i][0]) + '\nShipping Company: ' + allLaptop[i][1] + '\nShipping Cost: $' + allLaptop[i][2] +  '\n\n---------------------------------------------------------\n\n')
            grandTotal = grandTotal + int(results[i][3].replace('$',''))*allLaptop[i][0]

        with open(fileName, 'a') as f:
            vat = grandTotal / 100 * 13
            f.write("\nVAT Amount: $" + str(vat))
            f.write('\nGrand Total (with VAT & Shipping Cost): $' + str(grandTotal + vat + int(allLaptop[i][2])))

        print('\n\n Your selected laptops were added successfully to the stocks. \n')
    
    options()

#---------------------------------------------------------------------------------------------------------------------------
